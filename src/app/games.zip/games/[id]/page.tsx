"use client";

import { notFound } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { featuredGames, rankingHotDownloads } from '@/data/games';

interface GameDetailPageProps {
  params: {
    id: string;
  };
}

export default function GameDetailPage({ params }: GameDetailPageProps) {
  const gameId = parseInt(params.id);
  const game = featuredGames.find(g => g.id === gameId);
  
  if (!game) {
    notFound();
  }

  const mockReviews = [
    {
      id: 1,
      author: "心动",
      rating: 5,
      content: "一代大侠就要来了游戏人的心，所有的DLC都已完人了的，当时真的是有着奇千游戏的感觉以及自己回忆深度的细节，，，当时自己的游戏的感觉都只是非常不错，，，",
      likes: 102,
      device: "华为手机",
      deviceModel: "Redmi K70 Pro"
    },
    {
      id: 2,
      author: "学不清",
      rating: 5,
      content: "所有的玩法真算都在这，，，第一次是真的过瘾的，当时真的过瘾的游戏是，一次是真有不错的",
      likes: 19,
      timeAgo: "19小时前"
    }
  ];

  const relatedGames = [
    { id: 1, title: "心动小镇", rating: 8.8, status: "内测中", tags: ["模拟经营", "治愈", "多人联机"] },
    { id: 2, title: "大江湖2龙争与自省", rating: 8.1, tags: ["群侠", "武侠", "复古怀旧"] },
    { id: 3, title: "代号：代号", rating: 8.7, tags: ["射击", "开放世界", "角色扮演"] },
    { id: 4, title: "天域战：雷鸣青鸟", rating: 7.0, tags: ["战略", "卡牌", "角色扮演"] },
    { id: 5, title: "夏世天下 应用", rating: 7.8, tags: ["策略", "古风怀旧", "角色扮演"] },
    { id: 6, title: "埼千基地4：新主经教师养成史", rating: 7.2, tags: ["大富翁", "休息"] },
    { id: 7, title: "球球大作战", rating: 8.3, tags: ["UP主操作", "休闲"] },
    { id: 8, title: "逆转幻想传3", rating: 9.4, tags: ["回合", "美少女", "休闲"] }
  ];

  const adGames = [
    { id: 1, title: "心动小镇", rating: 8.8, status: "内测中", tags: ["模拟经营", "治愈", "多人联机"] },
    { id: 2, title: "香菇派对", rating: 8.6, status: "内测中", tags: ["射击", "收集", "放置"] },
    { id: 3, title: "伊蓝", rating: 7.8, tags: ["模拟", "10月25日首发"] }
  ];

  return (
    <div className="px-3 sm:px-4 py-4 sm:py-6">
      <div className="max-w-[1208px] mx-auto">
        <div className="flex gap-6">
          {/* 主内容区 */}
          <div className="flex-1 min-w-0">
            {/* 返回按钮 */}
            <div className="mb-4">
              <Link href="/games" className="inline-flex items-center gap-2 text-gray-400 hover:text-white">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/>
                </svg>
                返回
              </Link>
            </div>

            {/* 游戏主图和基本信息 */}
            <div className="bg-gray-900 rounded-xl overflow-hidden mb-6">
              <div className="relative aspect-[16/9]">
                <Image
                  src={game.image}
                  alt={game.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <h1 className="text-3xl font-bold text-white mb-2">{game.title}</h1>
                  <div className="flex items-center gap-4 text-white/80">
                    <span>官方入驻</span>
                    <div className="flex items-center gap-4">
                      <span>PC版</span>
                      <span>⚡</span>
                      <span>🎮</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 游戏统计信息 */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-teal-400">{game.rating || '9.4'}</div>
                <div className="text-sm text-gray-400">预约</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">8+</div>
                <div className="text-sm text-gray-400">适用年龄</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">2.2万</div>
                <div className="text-sm text-gray-400">关注</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">26年02</div>
                <div className="text-sm text-gray-400">上线日期</div>
              </div>
            </div>

            {/* 公告 */}
            <div className="bg-gray-800 rounded-lg p-4 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <span className="bg-teal-500 text-white text-xs px-2 py-1 rounded">公告</span>
                <span className="text-sm text-white">中期市 《大侠立志传外传》首日正式公测，名位大侠好找，预计的光辉期即将到达，不知不觉汉民以个项目日益感想的格拍下选出了最近，回望相聊反近不行，未能...</span>
              </div>
            </div>

            {/* 标签 */}
            <div className="flex flex-wrap gap-2 mb-6">
              {['单机', '角色扮演', '青春', '模拟'].map(tag => (
                <span key={tag} className="bg-gray-700 text-white px-3 py-1 rounded-full text-sm">
                  {tag}
                </span>
              ))}
            </div>

            {/* 游戏描述 */}
            <div className="bg-gray-800 rounded-lg p-4 mb-6">
              <div className="text-white text-sm leading-relaxed">
                《大侠立志传外传》是一款高度自由的独立制作角色扮演类游戏，把前者和平了，希望一百多的玩法和金钱可以得到程度最多数千规定的新玩攻略，改革者大大了，一百如前的的玩法, 成者人不想剑的都大如名，因为主流程简化相领地理的努力资源被推... 统前朗势—出此...
              </div>
              <div className="mt-4 flex items-center gap-4">
                <div className="flex items-center gap-2 text-teal-400">
                  <span>发行：心动</span>
                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <span>开发：半瓶醋工作室</span>
                </div>
              </div>
            </div>

            {/* 评价部分 */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white">评价 104 条</h3>
                <button className="text-teal-400 text-sm">写评价</button>
              </div>

              <div className="space-y-4">
                {mockReviews.map(review => (
                  <div key={review.id} className="bg-gray-800 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-teal-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                        {review.author[0]}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-white font-medium">{review.author}</span>
                          <div className="flex text-yellow-400">
                            {[...Array(review.rating)].map((_, i) => (
                              <span key={i}>★</span>
                            ))}
                          </div>
                          <span className="text-gray-400 text-sm">期待</span>
                        </div>
                        <p className="text-gray-300 text-sm mb-3">{review.content}</p>
                        <div className="flex items-center justify-between text-xs text-gray-400">
                          <div className="flex items-center gap-4">
                            {review.device && (
                              <span>{review.device}</span>
                            )}
                            {review.deviceModel && (
                              <span>{review.deviceModel}</span>
                            )}
                            {review.timeAgo && (
                              <span>{review.timeAgo}</span>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <button className="flex items-center gap-1 hover:text-white">
                              <span>👍</span>
                              <span>{review.likes}</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 右侧边栏 */}
          <div className="w-80 flex-shrink-0">
            {/* 关注 */}
            <div className="bg-gray-800 rounded-lg p-4 mb-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">心</span>
                </div>
                <div>
                  <div className="text-white font-medium">心动</div>
                  <div className="text-gray-400 text-sm">7501 评价 · 52 万关注</div>
                </div>
                <button className="ml-auto bg-teal-500 text-white px-4 py-1 rounded text-sm">关注</button>
              </div>
              <div className="flex gap-2">
                {[1,2,3,4,5].map(i => (
                  <div key={i} className="w-8 h-8 bg-gray-700 rounded"></div>
                ))}
              </div>
            </div>

            {/* 开发商 */}
            <div className="bg-gray-800 rounded-lg p-4 mb-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">半</span>
                </div>
                <div>
                  <div className="text-white font-medium">半瓶醋工作室</div>
                  <div className="text-gray-400 text-sm">143 评价 · 5797 关注</div>
                </div>
                <button className="ml-auto bg-teal-500 text-white px-4 py-1 rounded text-sm">关注</button>
              </div>
            </div>

            {/* 相关游戏 */}
            <div className="bg-gray-800 rounded-lg p-4 mb-4">
              <h4 className="text-white font-medium mb-3">相关游戏</h4>
              <div className="space-y-3">
                {relatedGames.slice(0, 6).map(relatedGame => (
                  <div key={relatedGame.id} className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gray-700 rounded-lg"></div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-white text-sm truncate">{relatedGame.title}</span>
                        {relatedGame.status && (
                          <span className="bg-teal-500 text-white text-xs px-1 py-0.5 rounded">{relatedGame.status}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-xs">
                        <span className="text-yellow-400">★{relatedGame.rating}</span>
                        <span className="text-gray-400">{relatedGame.tags.slice(0, 2).join('·')}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <button className="w-full text-teal-400 text-sm mt-3">查看全部</button>
            </div>

            {/* 广告位游戏 */}
            <div className="bg-gray-800 rounded-lg p-4">
              <h4 className="text-white font-medium mb-3">厂商其他游戏</h4>
              <div className="space-y-3">
                {adGames.map(adGame => (
                  <div key={adGame.id} className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gray-700 rounded-lg"></div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-white text-sm truncate">{adGame.title}</span>
                        {adGame.status && (
                          <span className="bg-teal-500 text-white text-xs px-1 py-0.5 rounded">{adGame.status}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-xs">
                        <span className="text-yellow-400">★{adGame.rating}</span>
                        <span className="text-gray-400">{adGame.tags.join('·')}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}